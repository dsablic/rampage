An invented filesystem for rampage tests.
